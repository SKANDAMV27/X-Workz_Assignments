enum PuchkariMaterial
{
	pastic,rubber,paper
}