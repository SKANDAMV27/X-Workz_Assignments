class Chain
{
	String chainMaterial;
	int chainWeight;
	int chainPrice;
	Chain(String chainMaterial,int chainWeight,int chainPrice)
	{
		this.chainMaterial=chainMaterial;
		this.chainWeight=chainWeight;
		this.chainPrice=chainPrice;
	}
	
}