class Harpic
{
	int volume;
	String flavor;
	int price;
	Harpic(int volume,String flavor,int price)
	{
		this.volume=volume;
		this.flavor=flavor;
		this.price=price;
	}
}