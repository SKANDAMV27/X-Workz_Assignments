class WhatsApp
{
	boolean login;
	boolean logout;
	int timeSpend;
	WhatsApp(boolean login,boolean logout,int timeSpend)
	{
		this.login=login;
		this.logout=logout;
		this.timeSpend=timeSpend;
	}
}