class Bar
{
	String barName;
	double contuctNumber;
	String open;
	Bar(String barName,double contuctNumber,String	open)
	{
		this.barName=barName;
		this.contuctNumber=contuctNumber;
		this.open=open;
	}
}