class Chat
{
	int number;
	String type;
	String location;
	Chat(int number,String type,String location)
	{
		this.number=number;
		this.type=type;
		this.location=location;
	}
}