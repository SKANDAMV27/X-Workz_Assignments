class Magnet
{
	int number;
	String working;
	char grade;
	Magnet(int number,String working,char grade)
	{
		this.number=number;
		this.working=working;
		this.grade=grade;
	}
	
}