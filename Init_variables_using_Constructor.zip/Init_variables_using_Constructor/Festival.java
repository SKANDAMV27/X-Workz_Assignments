class Festival
{
	String name;
	String date;
	String day;
	
	Festival(String name,String date,String day)
	{
		this.name=name;
		this.date=date;
		this.day=day;
	}
	
}