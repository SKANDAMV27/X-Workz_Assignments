class Sagar
{
	String eduction;
	int marks;
	char grade;
	Sagar(String eduction,int marks,char grade)
	{
		this.eduction=eduction;
		this.marks=marks;
		this.grade=grade;
	}
}