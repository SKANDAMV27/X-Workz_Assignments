class Anklet
{
	String material;
	int price;
	int kg;
	Anklet(String material,int price,int kg)
	{
		this.material=material;
		this.price=price;
		this.kg=kg;
	}
}