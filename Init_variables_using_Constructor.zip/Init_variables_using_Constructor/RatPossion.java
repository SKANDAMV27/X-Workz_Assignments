class RatPossion
{
	String ratPossionType;
	boolean strong;
	int required;
	RatPossion(String ratPossionType,boolean strong,int required)
	{
		this.ratPossionType=ratPossionType;
		this.strong=strong;
		this.required=required;
	}
	
}