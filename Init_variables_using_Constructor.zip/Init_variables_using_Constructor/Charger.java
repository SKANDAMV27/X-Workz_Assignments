class Charger
{
	String type;
	int voltage;
	String company;
	Charger(String type,int voltage,String company)
	{
		this.type=type;
		this.voltage=voltage;
		this.company=company;
		
	}
}