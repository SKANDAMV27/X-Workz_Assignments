class Face
{
	String colour;
	int size;
	String shape;
	Face(String colour,int size,String shape)
	{
		this.colour=colour;
		this.size=size;
		this.shape=shape;
	}
}